class InitialInfo:
    CREATOR = ""
    VIEWS_BEFORE = 0
